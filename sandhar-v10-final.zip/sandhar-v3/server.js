/**
 * Sandhar Energy Platform — v3.0 (SQLite)
 * Open: http://localhost:3000/login.html
 */
const express  = require('express');
const path     = require('path');
const fs       = require('fs');
const multer   = require('multer');
const Database = require('better-sqlite3');

const app  = express();
const PORT = 3000;
const DB_PATH     = path.join(__dirname, 'database', 'sandhar.db');
const UPLOAD_DIR  = path.join(__dirname, 'uploads');

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename:    (req, file, cb) => cb(null, Date.now() + '_' + file.originalname)
});
const upload = multer({ storage, limits: { fileSize: 50 * 1024 * 1024 } });

// ── DB helpers ────────────────────────────────────────────────
function db() {
  const conn = new Database(DB_PATH);
  conn.pragma('foreign_keys = OFF'); // avoid FK ordering issues during bulk BRSR import
  return conn;
}
function delta(c, p) { return p ? Math.round(1000*(c-p)/p)/10 : 0; }

// ── Pages ─────────────────────────────────────────────────────
const PAGES = { '/':'index.html','/solar':'solar.html','/wind':'wind.html',
  '/energy':'energy.html','/fuel':'fuel.html','/water':'water.html',
  '/waste':'waste.html','/carbon':'carbon.html','/dg':'dg.html',
  '/data-management':'data-management.html','/admin':'admin.html' };
Object.entries(PAGES).forEach(([r,f]) =>
  app.get(r, (req,res) => res.sendFile(path.join(__dirname,'public',f))));

// ── API: Plants ───────────────────────────────────────────────
app.get('/api/plants', (req, res) => {
  const d = db();
  res.json(d.prepare('SELECT * FROM plants ORDER BY plant_code').all());
  d.close();
});

// ── API: Months ───────────────────────────────────────────────
app.get('/api/months', (req, res) => {
  const d = db();
  const rows = d.prepare('SELECT DISTINCT month FROM energy_monthly ORDER BY month').all();
  d.close();
  res.json(rows.map(r => r.month));
});

// ── API: KPIs ─────────────────────────────────────────────────
app.get('/api/kpis', (req, res) => {
  const d = db();
  const months = d.prepare('SELECT DISTINCT month FROM energy_monthly ORDER BY month').all().map(r=>r.month);
  const requestedMonth = req.query.month;
  const latest = (requestedMonth && months.includes(requestedMonth)) ? requestedMonth : months[months.length-1];
  const latestIdx = months.indexOf(latest);
  const prev = latestIdx > 0 ? months[latestIdx-1] : months[months.length-2];

  const tot = (m) => d.prepare(`SELECT
    SUM(grid_consumption_kwh) g, SUM(solar_generation_kwh) s,
    SUM(wind_generation_kwh) w, SUM(dg_consumption_ltr) dg,
    SUM(lpg_consumption_kg) lpg, SUM(water_consumption_kl) water,
    SUM(waste_generated_kg) waste, SUM(carbon_emissions_tco2e) carbon,
    SUM(energy_cost_inr) cost FROM energy_monthly WHERE month=?`).get(m);

  const c = tot(latest), p = tot(prev);
  d.close();

  const renC = c.s+c.w, totC = renC+c.g;
  const renP = p.s+p.w, totP = renP+p.g;
  const renPct  = totC ? Math.round(1000*renC/totC)/10 : 0;
  const renPctP = totP ? Math.round(1000*renP/totP)/10 : 0;

  res.json({ month: latest, kpis: {
    total_consumption_kvah:      Math.round(c.g),
    total_consumption_delta_pct: delta(c.g,p.g),
    renewable_pct:               renPct,
    renewable_pct_delta:         Math.round((renPct-renPctP)*10)/10,
    carbon_tco2e:                Math.round(c.carbon*10)/10,
    carbon_delta_pct:            delta(c.carbon,p.carbon),
    energy_cost_inr:             Math.round(c.cost),
    cost_delta_pct:              delta(c.cost,p.cost),
    water_kl:                    Math.round(c.water),
    water_delta_pct:             delta(c.water,p.water),
    waste_kg:                    Math.round(c.waste),
    dg_ltr:                      Math.round(c.dg),
    dg_delta_pct:                delta(c.dg,p.dg),
    lpg_kg:                      Math.round(c.lpg),
    solar_kvah:                  Math.round(c.s),
  }});
});

// ── API: Energy trend ─────────────────────────────────────────
app.get('/api/energy-trend', (req, res) => {
  const d = db();
  const rows = d.prepare(`SELECT month,
    SUM(grid_consumption_kwh) grid, SUM(solar_generation_kwh) solar,
    SUM(wind_generation_kwh) wind, SUM(dg_consumption_ltr) dg,
    SUM(lpg_consumption_kg) lpg, SUM(water_consumption_kl) water,
    SUM(waste_generated_kg) waste, SUM(carbon_emissions_tco2e) carbon,
    SUM(energy_cost_inr) cost
    FROM energy_monthly GROUP BY month ORDER BY month`).all();
  d.close();
  res.json(rows);
});

// ── API: Plant comparison ─────────────────────────────────────
app.get('/api/plant-comparison', (req, res) => {
  const d = db();
  const months = d.prepare('SELECT DISTINCT month FROM energy_monthly ORDER BY month').all().map(r=>r.month);
  const month  = req.query.month && months.includes(req.query.month)
    ? req.query.month : months[months.length-1];

  const rows = d.prepare(`SELECT p.plant_code, p.solar_capacity_kwp, p.capex_kwp, p.opex_kwp,
    e.grid_consumption_kwh grid, e.solar_generation_kwh solar, e.wind_generation_kwh wind,
    e.carbon_emissions_tco2e carbon, e.energy_cost_inr cost,
    e.water_consumption_kl water, e.dg_consumption_ltr dg,
    e.lpg_consumption_kg lpg, e.waste_generated_kg waste
    FROM plants p JOIN energy_monthly e ON p.plant_code=e.plant_code
    WHERE e.month=? ORDER BY e.grid_consumption_kwh DESC`).all(month);
  d.close();

  res.json(rows.map(r => {
    const ren=r.solar+r.wind, tot=ren+r.grid;
    const pct=tot?Math.round(1000*ren/tot)/10:0;
    return {...r, renewable_pct:pct, status:pct>=25?'good':pct>=10?'watch':'attention'};
  }));
});

// ── API: Solar & Wind ─────────────────────────────────────────
app.get('/api/solar-wind', (req, res) => {
  const d = db();
  const plant = req.query.plant||'ALL';
  const rows = plant==='ALL'
    ? d.prepare(`SELECT month, SUM(solar_generation_kwh) solar, SUM(wind_generation_kwh) wind, SUM(grid_consumption_kwh) grid FROM energy_monthly GROUP BY month ORDER BY month`).all()
    : d.prepare(`SELECT month, solar_generation_kwh solar, wind_generation_kwh wind, grid_consumption_kwh grid FROM energy_monthly WHERE plant_code=? ORDER BY month`).all(plant);
  d.close();
  res.json(rows);
});

app.get('/api/solar-wind/plant-mix', (req, res) => {
  const d = db();
  const latest = d.prepare('SELECT MAX(month) m FROM energy_monthly').get().m;
  const rows = d.prepare(`SELECT p.plant_code name, p.solar_capacity_kwp,
    e.solar_generation_kwh solar, e.wind_generation_kwh wind
    FROM plants p JOIN energy_monthly e ON p.plant_code=e.plant_code
    WHERE e.month=? ORDER BY e.solar_generation_kwh DESC`).all(latest);
  d.close();
  res.json(rows);
});

// ── API: Solar plants ─────────────────────────────────────────
app.get('/api/solar-plants', (req, res) => {
  const d = db();
  const rows = d.prepare(`SELECT p.plant_code, p.solar_capacity_kwp, p.capex_kwp, p.opex_kwp,
    SUM(e.solar_generation_kwh) total_solar, SUM(e.grid_consumption_kwh) total_grid,
    COUNT(e.month) months_reported
    FROM plants p LEFT JOIN energy_monthly e ON p.plant_code=e.plant_code
    GROUP BY p.plant_code HAVING total_solar>0 OR p.solar_capacity_kwp>0
    ORDER BY p.solar_capacity_kwp DESC`).all();
  d.close();
  res.json(rows);
});

// ── API: Trend routes ─────────────────────────────────────────
function trendRoute(col, alias) {
  return (req, res) => {
    const d = db();
    const plant = req.query.plant||'ALL';
    const rows = plant==='ALL'
      ? d.prepare(`SELECT month, SUM(${col}) ${alias} FROM energy_monthly GROUP BY month ORDER BY month`).all()
      : d.prepare(`SELECT month, ${col} ${alias} FROM energy_monthly WHERE plant_code=? ORDER BY month`).all(plant);
    d.close();
    res.json(rows);
  };
}
app.get('/api/water-trend',  trendRoute('water_consumption_kl',  'water'));
app.get('/api/waste-trend',  trendRoute('waste_generated_kg',    'waste'));
app.get('/api/carbon-trend', trendRoute('carbon_emissions_tco2e','carbon'));
app.get('/api/dg-trend',     trendRoute('dg_consumption_ltr',    'dg'));
app.get('/api/lpg-trend',    trendRoute('lpg_consumption_kg',    'lpg'));

// ── API: Year-over-year comparison ────────────────────────────
app.get('/api/yoy', (req, res) => {
  const d = db();
  const metric = req.query.metric || 'grid_consumption_kwh';
  const allowed = ['grid_consumption_kwh','solar_generation_kwh','dg_consumption_ltr',
    'lpg_consumption_kg','water_consumption_kl','waste_generated_kg','carbon_emissions_tco2e'];
  if (!allowed.includes(metric)) return res.status(400).json({error:'Invalid metric'});

  const rows = d.prepare(`SELECT
    substr(month,1,4) year,
    substr(month,6,2) mon,
    SUM(${metric}) val
    FROM energy_monthly GROUP BY month ORDER BY month`).all();
  d.close();

  // Group by year
  const byYear = {};
  for (const r of rows) {
    if (!byYear[r.year]) byYear[r.year] = {};
    byYear[r.year][r.mon] = r.val;
  }
  res.json(byYear);
});

// ── API: Save capacity ────────────────────────────────────────
app.post('/api/capacity', (req, res) => {
  const { plant_code, capex_kwp, opex_kwp } = req.body;
  if (!plant_code) return res.status(400).json({error:'plant_code required'});
  const d = db();
  const total = (capex_kwp||0)+(opex_kwp||0);
  d.prepare('UPDATE plants SET solar_capacity_kwp=?, capex_kwp=?, opex_kwp=? WHERE plant_code=?')
   .run(total, capex_kwp||0, opex_kwp||0, plant_code);
  d.close();
  res.json({message:`✅ Capacity saved for ${plant_code}: ${total} kWp`});
});

// ── API: CSV export ───────────────────────────────────────────
app.get('/api/export/:type.csv', (req, res) => {
  const d = db();
  const plant = req.query.plant||'ALL';
  const type  = req.params.type;
  const colMap = {
    'solar-wind':'solar_generation_kwh solar, wind_generation_kwh wind',
    'energy':    'grid_consumption_kwh grid, solar_generation_kwh solar',
    'water':     'water_consumption_kl water',
    'waste':     'waste_generated_kg waste',
    'carbon':    'carbon_emissions_tco2e carbon',
    'dg':        'dg_consumption_ltr dg',
    'lpg':       'lpg_consumption_kg lpg',
    'all':       'grid_consumption_kwh grid, solar_generation_kwh solar, dg_consumption_ltr dg, lpg_consumption_kg lpg, water_consumption_kl water, waste_generated_kg waste, carbon_emissions_tco2e carbon, energy_cost_inr cost',
  };
  const cols = colMap[type]||'grid_consumption_kwh grid';
  const rows = plant==='ALL'
    ? d.prepare(`SELECT p.plant_code plant, e.month, ${cols} FROM energy_monthly e JOIN plants p ON p.plant_code=e.plant_code ORDER BY p.plant_code, e.month`).all()
    : d.prepare(`SELECT p.plant_code plant, e.month, ${cols} FROM energy_monthly e JOIN plants p ON p.plant_code=e.plant_code WHERE e.plant_code=? ORDER BY e.month`).all(plant);
  d.close();
  if (!rows.length) return res.status(404).json({error:'No data'});
  const headers = Object.keys(rows[0]).join(',');
  const lines   = rows.map(r=>Object.values(r).join(','));
  res.setHeader('Content-Type','text/csv');
  res.setHeader('Content-Disposition',`attachment; filename="sandhar_${type}_${plant}.csv"`);
  res.send([headers,...lines].join('\n'));
});

// ── API: Uploads list ─────────────────────────────────────────
app.get('/api/uploads', (req, res) => {
  const d = db();
  const rows = d.prepare('SELECT * FROM uploads ORDER BY uploaded_at DESC LIMIT 50').all();
  d.close();
  res.json(rows);
});

// ── API: BRSR Upload & Import ─────────────────────────────────
app.post('/api/uploads', upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({error:'No file provided'});

  const filePath = req.file.path;
  const fileName = req.file.originalname;
  const fileType = req.body.file_type||'brsr';

  // Log upload immediately
  const d = db();
  const uploadId = d.prepare(`INSERT INTO uploads (filename, file_type, uploaded_at, status)
    VALUES (?,?,?,?)`).run(fileName, fileType, new Date().toISOString(), 'processing').lastInsertRowid;
  d.close();

  try {
    // Only auto-import BRSR files
    if (fileType === 'brsr' || fileType === 'brsr_monthly') {
      const result = await importBRSR(filePath);
      const d2 = db();
      d2.prepare('UPDATE uploads SET status=?, records_added=?, records_skipped=? WHERE id=?')
        .run('imported', result.added, result.skipped, uploadId);
      d2.close();
      res.json({
        message: `✅ ${fileName} imported — ${result.added} records added, ${result.skipped} already existed`,
        added: result.added, skipped: result.skipped
      });
    } else {
      const d2 = db();
      d2.prepare('UPDATE uploads SET status=? WHERE id=?').run('received', uploadId);
      d2.close();
      res.json({message:`✅ ${fileName} uploaded successfully`});
    }
  } catch (err) {
    const d2 = db();
    d2.prepare('UPDATE uploads SET status=? WHERE id=?').run('error: '+err.message.slice(0,100), uploadId);
    d2.close();
    res.status(500).json({error:'Import failed: '+err.message});
  }
});

// ── BRSR Import Logic ─────────────────────────────────────────
async function importBRSR(filePath) {
  let XLSX;
  try { XLSX = require('xlsx'); }
  catch(e) { throw new Error('xlsx package not installed. Run: npm install xlsx'); }

  const wb = XLSX.readFile(filePath, { cellDates:false, raw:true });
  const SKIP = new Set(['Automotive','Corp & SASPL','Plastic','Sheetmetal & Automach','JV','Sheet1','CFD','CMT']);

  let records = [];

  // Inspect EVERY sheet individually — don't rely on sheet name.
  // A sheet is "wide" (plants as columns, one month) if its "Unit Name" row
  // has multiple DIFFERENT plant codes across columns.
  // A sheet is "narrow" (yearly, one plant per sheet, months as columns) if it
  // has "Month Name" but no "Unit Name" row (or Unit Name is just the sheet's own plant).
  for (const sheetName of wb.SheetNames) {
    if (SKIP.has(sheetName)) continue;
    const ws = wb.Sheets[sheetName];
    if (!ws) continue;

    const data = XLSX.utils.sheet_to_json(ws, { header:1, defval:null });
    const rows = {};
    for (const row of data) {
      if (row[0]) { const l = String(row[0]).trim(); if (!rows[l]) rows[l] = row.slice(1); }
    }

    if (!rows['Month Name'] || !rows['Total Grid electricity consumption']) continue;

    const unitNameRow = rows['Unit Name'];
    const distinctUnits = unitNameRow
      ? new Set(unitNameRow.filter(v => v !== null && v !== undefined && String(v).trim() !== ''))
      : new Set();

    if (distinctUnits.size > 1) {
      // WIDE format: plants as columns, single (or repeated) month
      records = records.concat(parseWideSheet(rows));
    } else {
      // NARROW format: this whole sheet belongs to ONE plant (the sheet name itself),
      // months run across columns
      records = records.concat(parseNarrowSheet(sheetName.trim(), rows));
    }
  }

  if (!records.length) throw new Error('No data found in file — check that it matches a known BRSR layout');

  // Insert into DB
  const d = db();
  let added=0, skipped=0;

  const MONTH_MAP2 = {'jan':'01','feb':'02','mar':'03','apr':'04','may':'05','jun':'06',
    'jul':'07','aug':'08','sep':'09','oct':'10','nov':'11','dec':'12','june':'06'};

  const insertPlant = d.prepare(`INSERT OR IGNORE INTO plants (plant_code,name,region) VALUES (?,?,?)`);
  const insertEnergy = d.prepare(`INSERT OR IGNORE INTO energy_monthly
    (plant_code,month,grid_consumption_kwh,solar_generation_kwh,wind_generation_kwh,
     dg_consumption_ltr,lpg_consumption_kg,water_consumption_kl,waste_generated_kg,
     waste_recycled_kg,carbon_emissions_tco2e,energy_cost_inr)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`);

  const insertMany = d.transaction((recs) => {
    for (const r of recs) {
      insertPlant.run(r.plant_code, r.plant_code, 'Unspecified');
      const info = insertEnergy.run(
        r.plant_code, r.month, r.grid, r.solar, 0,
        r.dg, r.lpg, r.water, r.waste, 0, r.carbon, r.cost
      );
      if (info.changes > 0) added++; else skipped++;
    }
  });

  insertMany(records);
  d.close();
  return { added, skipped };
}

// WIDE sheet: one row per metric, plants running across columns, month usually repeated.
// Works for both "BRSR Required Details"-style files AND unnamed "MONTHLY MIS" sheets.
function parseWideSheet(rows) {
  const plantsRaw = rows['Unit Name'] || [];
  const monthsRaw = rows['Month Name'] || [];
  const records = [];

  const findRow = (...labels) => {
    for (const l of labels) if (rows[l]) return rows[l];
    return [];
  };

  for (let i = 0; i < plantsRaw.length; i++) {
    const code  = extractPlantCode(plantsRaw[i]);
    const month = parseBRSRMonth(monthsRaw[i]);
    if (!code || !month) continue;

    const g = (l) => toNum((rows[l] || [])[i]);
    const grid  = g('Total Grid electricity consumption');
    const solar = g('Solar Power Generation Details');
    if (!grid && !solar) continue; // nothing reported for this plant this month

    const dg    = g('Diesel consumption');
    const lpg   = g('LPG/PNG Consumption');
    const water = g('Surface water') + g('Groundwater') + g('Third party water');
    const waste = g('ETP Sludge Waste (Kg)') + g('ETP Sludge Waste')
                + g('STP Sludge Waste (Kg)') + g('STP Sludge Waste')
                + g('Paint Sludge Waste (Kg)') + g('Paint Sludge Waste')
                + g('Grease (Kg)') + g('Grease');

    records.push({
      plant_code: code, month, grid, solar, dg, lpg, water, waste,
      carbon: (grid*0.716 + dg*2.68) / 1000, cost: grid*8.5
    });
  }
  return records;
}

// NARROW sheet: this sheet belongs to a single plant (its own sheet name),
// months run across the columns instead of plants.
function parseNarrowSheet(plantCode, rows) {
  const monthsRow = rows['Month Name'] || [];
  const records = [];

  for (let i = 0; i < monthsRow.length; i++) {
    const month = parseBRSRMonth(monthsRow[i]);
    if (!month) continue;

    const g = (l) => toNum((rows[l] || [])[i]);
    const grid  = g('Total Grid electricity consumption');
    const solar = g('Solar Power Generation Details');
    if (!grid && !solar) continue;

    const dg    = g('Diesel consumption');
    const lpg   = g('LPG/PNG Consumption');
    const water = g('Surface water') + g('Groundwater') + g('Third party water');
    const waste = g('ETP Sludge Waste (Kg)') + g('ETP Sludge Waste')
                + g('STP Sludge Waste (Kg)') + g('STP Sludge Waste')
                + g('Paint Sludge Waste (Kg)') + g('Paint Sludge Waste')
                + g('Grease (Kg)') + g('Grease');

    records.push({
      plant_code: plantCode, month, grid, solar, dg, lpg, water, waste,
      carbon: (grid*0.716 + dg*2.68) / 1000, cost: grid*8.5
    });
  }
  return records;
}

function extractPlantCode(name) {
  if (!name) return null;
  name = String(name).trim();
  const m = name.match(/\(([A-Z0-9]+(?:\([A-Z]+\))?)\)\s*$/);
  if (m) { const inner=m[1]; const m2=inner.match(/\(([A-Z]+)\)/); return m2?m2[1]:inner; }
  if (/^[A-Z0-9]+$/.test(name)) return name;
  return name;
}

function parseBRSRMonth(label) {
  if (!label) return null;
  const m = String(label).trim().match(/([A-Za-z]+)'(\d{2})/);
  if (!m) return null;
  const MAP={'jan':'01','feb':'02','mar':'03','apr':'04','may':'05','jun':'06',
    'jul':'07','aug':'08','sep':'09','oct':'10','nov':'11','dec':'12','june':'06'};
  const mn = MAP[m[1].toLowerCase().slice(0,3)];
  return mn ? `${2000+parseInt(m[2])}-${mn}` : null;
}

function toNum(v) {
  if (v===null||v===undefined) return 0;
  const s=String(v).replace(/,/g,'').trim();
  if (!s||s==='-'||s==='N/A') return 0;
  const n=parseFloat(s); return isNaN(n)?0:n;
}

// ── API: Chatbot ──────────────────────────────────────────────
app.post('/api/chat', (req, res) => {
  const q = (req.body.question||'').toLowerCase().trim();
  const d = db();
  const months = d.prepare('SELECT DISTINCT month FROM energy_monthly ORDER BY month').all().map(r=>r.month);
  const latest = months[months.length-1];
  const fmtM = ym=>{const[y,m]=ym.split('-');return['','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][+m]+' '+y;};
  const f = (n,dec=0)=>Number(n||0).toLocaleString('en-IN',{maximumFractionDigits:dec,minimumFractionDigits:dec});

  const cur = d.prepare(`SELECT SUM(grid_consumption_kwh) g, SUM(solar_generation_kwh) s,
    SUM(dg_consumption_ltr) dg, SUM(lpg_consumption_kg) lpg,
    SUM(water_consumption_kl) water, SUM(waste_generated_kg) waste,
    SUM(carbon_emissions_tco2e) carbon, SUM(energy_cost_inr) cost
    FROM energy_monthly WHERE month=?`).get(latest);

  const yearly = d.prepare(`SELECT SUM(grid_consumption_kwh) g, SUM(solar_generation_kwh) s,
    SUM(dg_consumption_ltr) dg, SUM(lpg_consumption_kg) lpg,
    SUM(water_consumption_kl) water, SUM(waste_generated_kg) waste,
    SUM(carbon_emissions_tco2e) carbon, SUM(energy_cost_inr) cost
    FROM energy_monthly`).get();

  const topGrid  = d.prepare(`SELECT plant_code, SUM(grid_consumption_kwh) v FROM energy_monthly GROUP BY plant_code ORDER BY v DESC LIMIT 1`).get();
  const topSolar = d.prepare(`SELECT plant_code, SUM(solar_generation_kwh) v FROM energy_monthly GROUP BY plant_code ORDER BY v DESC LIMIT 1`).get();
  const solarCap = d.prepare(`SELECT SUM(solar_capacity_kwp) total, SUM(capex_kwp) capex, SUM(opex_kwp) opex FROM plants`).get();
  const plantCount = d.prepare(`SELECT COUNT(*) cnt FROM plants`).get().cnt;
  const solarCount = d.prepare(`SELECT COUNT(*) cnt FROM plants WHERE solar_capacity_kwp>0`).get().cnt;
  const yearCount  = d.prepare(`SELECT COUNT(DISTINCT substr(month,1,4)) cnt FROM energy_monthly`).get().cnt;
  d.close();

  const renPct = cur.g+cur.s?(100*cur.s/(cur.g+cur.s)).toFixed(1):0;
  let answer='';

  if (q.includes('solar')&&(q.includes('capex')||q.includes('opex')||q.includes('capacity')))
    answer=`${solarCount} plants have solar. Total: ${f(solarCap.total)} kWp — CAPEX (owned): ${f(solarCap.capex)} kWp, OPEX (leased): ${f(solarCap.opex)} kWp.`;
  else if (q.includes('solar')||q.includes('renewable'))
    answer=`Solar in ${fmtM(latest)}: ${f(cur.s)} kVAh (${renPct}% of total). Full year: ${f(yearly.s/1000,1)} MWh. Top solar plant: ${topSolar?.plant_code}.`;
  else if (q.includes('grid')||q.includes('electricity')||q.includes('consumption'))
    answer=`Grid in ${fmtM(latest)}: ${f(cur.g)} kVAh. Full data (${yearCount} year/s): ${f(yearly.g/1e6,2)} MVAh. Highest consumer: ${topGrid?.plant_code}.`;
  else if (q.includes('carbon')||q.includes('emission')||q.includes('co2'))
    answer=`Carbon in ${fmtM(latest)}: ${f(cur.carbon,1)} tCO₂e. All data total: ${f(yearly.carbon,0)} tCO₂e (estimated, CEA factor).`;
  else if (q.includes('water'))
    answer=`Water in ${fmtM(latest)}: ${f(cur.water)} kL. All data total: ${f(yearly.water)} kL.`;
  else if (q.includes('waste'))
    answer=`Waste in ${fmtM(latest)}: ${f(cur.waste)} kg. All data total: ${f(yearly.waste)} kg.`;
  else if (q.includes('lpg')||q.includes('png')||q.includes('gas'))
    answer=`LPG/PNG in ${fmtM(latest)}: ${f(cur.lpg)} kg. All data total: ${f(yearly.lpg)} kg.`;
  else if (q.includes('dg')||q.includes('diesel'))
    answer=`DG diesel in ${fmtM(latest)}: ${f(cur.dg)} litres. All data total: ${f(yearly.dg)} litres.`;
  else if (q.includes('cost')||q.includes('bill'))
    answer=`Energy cost in ${fmtM(latest)}: ₹${f(cur.cost/100000,1)} Lakhs (est. ₹8.5/kVAh). All data: ₹${f(yearly.cost/1e7,2)} Crores.`;
  else if (q.includes('year')||q.includes('how many year'))
    answer=`The platform currently has ${yearCount} year(s) of data across ${months.length} months (${fmtM(months[0])} to ${fmtM(latest)}). Upload more BRSR files in Data Management to add more years.`;
  else if (q.includes('upload')||q.includes('add data')||q.includes('import'))
    answer=`Go to Data Management, select file type "BRSR Report", choose your Excel file and click Upload. The system auto-detects monthly or yearly format and imports immediately — no manual steps needed.`;
  else if (q.includes('top')||q.includes('highest')||q.includes('most'))
    answer=`Top energy consumer: ${topGrid?.plant_code}. Top solar generator: ${topSolar?.plant_code}. Use Plant Compare tab on dashboard to compare any two plants.`;
  else if (q.includes('hello')||q.includes('hi'))
    answer=`Hello! I'm your Sandhar Energy AI. Ask me about grid, solar, carbon, water, waste, LPG, DG, costs, plant comparisons, or how to upload new data!`;
  else if (q.includes('help')||q.includes('what can'))
    answer=`I can help with: ⚡ Grid | ☀️ Solar & CAPEX/OPEX | 🌱 Carbon | 💧 Water | ♻️ Waste | 🔥 LPG | 🛢️ DG | 💰 Costs | 📅 Year-over-year | 🏭 Plant compare. Just ask!`;
  else
    answer=`Try: "Solar share this month?", "Top energy plant?", "Total carbon this year?", "How do I upload new data?"`;

  res.json({answer});
});

// ── API: Electricity Bills ────────────────────────────────────
function ensureBillsTable() {
  const d = db();
  d.exec(`CREATE TABLE IF NOT EXISTS electricity_bills (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    plant_code TEXT NOT NULL,
    month TEXT NOT NULL,
    units_consumed REAL DEFAULT 0,
    fixed_charges REAL DEFAULT 0,
    energy_charges REAL DEFAULT 0,
    tax_amount REAL DEFAULT 0,
    total_amount REAL DEFAULT 0,
    max_demand REAL DEFAULT 0,
    entered_at TEXT NOT NULL,
    UNIQUE(plant_code, month)
  )`);
  d.close();
}
ensureBillsTable();

app.post('/api/bills', (req, res) => {
  const { plant_code, month, units_consumed, fixed_charges, energy_charges, tax_amount, total_amount, max_demand } = req.body;
  if (!plant_code || !month) return res.status(400).json({error:'plant_code and month required'});
  const d = db();
  try {
    d.prepare(`INSERT OR REPLACE INTO electricity_bills
      (plant_code, month, units_consumed, fixed_charges, energy_charges, tax_amount, total_amount, max_demand, entered_at)
      VALUES (?,?,?,?,?,?,?,?,?)`).run(
      plant_code, month, units_consumed||0, fixed_charges||0, energy_charges||0,
      tax_amount||0, total_amount||0, max_demand||0, new Date().toISOString()
    );
    d.close();
    res.json({message:`✅ Bill saved for ${plant_code} — ${month}`});
  } catch(e) {
    d.close();
    res.status(500).json({error: e.message});
  }
});

app.get('/api/bills', (req, res) => {
  const d = db();
  const plant = req.query.plant;
  const rows = plant
    ? d.prepare('SELECT * FROM electricity_bills WHERE plant_code=? ORDER BY month DESC').all(plant)
    : d.prepare('SELECT * FROM electricity_bills ORDER BY month DESC LIMIT 100').all();
  d.close();
  res.json(rows);
});

// ── Start ─────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════════════╗
║   Sandhar Energy Platform — v3.0 (SQLite)    ║
║   Open: http://localhost:${PORT}/login.html    ║
╚══════════════════════════════════════════════╝
  `);
});
